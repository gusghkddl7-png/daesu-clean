export default function Dashboard() {
  return (
    <main style={{minHeight:"100svh",display:"grid",placeItems:"center",background:"#0f1115",color:"#e6e6e6"}}>
      <div style={{padding:"24px 28px",borderRadius:16,background:"rgba(255,255,255,.03)",border:"1px solid rgba(255,255,255,.08)"}}>
        대시보드(임시) — 로그인 성공!
      </div>
    </main>
  );
}