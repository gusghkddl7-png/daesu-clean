﻿Backup Label : backup-015-20250919-162529
Source       : C:\Users\대수\Downloads\daesu-clean
Created At   : 2025-09-19 16:25:30
Note         : node_modules, .next 등은 제외됨
