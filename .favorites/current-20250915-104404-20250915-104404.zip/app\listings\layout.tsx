﻿export default function ListingsLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
