"use client";
import { useRouter } from "next/navigation";
export default function Page(){
  const router = useRouter();
  return (
    <div className="screen">
      <div className="card">
        <div className="title">고객/문의</div>
        <div className="desc">고객 파이프라인, 문의 관리 화면을 준비 중입니다.</div>
        <div className="btns">
          <button className="btn" onClick={()=>router.push("/dashboard")}>대시보드로</button>
        </div>
      </div>
      <style jsx>{`
  .screen{min-height:100svh;display:grid;place-items:center;padding:24px;background:linear-gradient(180deg,#fff,#f6f7f8);color:#111}
  .card{width:min(720px,92vw);border-radius:20px;padding:26px;background:#fff;border:1px solid #e5e7eb;box-shadow:0 10px 30px rgba(0,0,0,.06)}
  .title{font-size:20px;font-weight:900;margin-bottom:8px}
  .desc{color:#555;margin-bottom:16px}
  .btns{display:flex;gap:10px;flex-wrap:wrap}
  .btn{display:inline-flex;justify-content:center;align-items:center;padding:10px 14px;border-radius:12px;font-weight:800;border:1px solid #111;background:#111;color:#fff;cursor:pointer}
  .btn.ghost{border:1px dashed rgba(0,0,0,.5);background:transparent;color:#111}
  .btn.ghost:hover{border-style:solid}
`}</style>
    </div>
  );
}