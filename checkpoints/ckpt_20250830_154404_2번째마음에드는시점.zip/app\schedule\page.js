"use client";
import Link from "next/link";
import { useMemo, useState } from "react";

const WEEKS = ["일","월","화","수","목","금","토"];

const HOLIDAYS_2025 = {
  "2025-01-01":"신정",
  "2025-03-01":"삼일절","2025-03-03":"대체공휴일",
  "2025-05-05":"어린이날 · 부처님오신날","2025-05-06":"대체공휴일",
  "2025-06-06":"현충일",
  "2025-08-15":"광복절",
  "2025-10-03":"개천절","2025-10-05":"추석 연휴","2025-10-06":"추석","2025-10-07":"추석 연휴","2025-10-08":"대체공휴일","2025-10-09":"한글날",
  "2025-12-25":"성탄절",
  "2025-01-28":"설날 연휴","2025-01-29":"설날","2025-01-30":"설날 연휴"
};

const ymd = d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
const loadEvents = () => { try { return JSON.parse(localStorage.getItem("daesu:events")||"[]"); } catch { return []; } };

export default function SchedulePage(){
  const [cursor,setCursor] = useState(()=>{ const n=new Date(); return new Date(n.getFullYear(),n.getMonth(),1); });

  const y = cursor.getFullYear();
  const m = cursor.getMonth();
  const first = new Date(y,m,1);
  const last  = new Date(y,m+1,0);
  const blanks = first.getDay();
  const total  = blanks + last.getDate();
  const cells  = Math.ceil(total/7)*7;

  const days = useMemo(()=>Array.from({length:cells},(_,i)=>{
    const d = i - blanks + 1;
    const date = new Date(y,m,d);
    const key  = ymd(date);
    const other = d<=0 || d>last.getDate();
    const events = other ? [] : loadEvents()
      .filter(ev=>ev.date===key)
      .sort((a,b)=>String(a.time||"").localeCompare(String(b.time||"")));
    const holiday = other ? null : HOLIDAYS_2025[key];
    return { date, key, other, events, holiday, dow:i%7 };
  }),[y,m,blanks,cells,last]);

  const move  = (delta)=>setCursor(new Date(y,m+delta,1));
  const today = ()=>{ const n=new Date(); setCursor(new Date(n.getFullYear(),n.getMonth(),1)); };
  const addEvent = (dateStr)=>{ alert(`등록 폼은 다음 단계에서 연결합니다.\n날짜: ${dateStr}`); };

  return (
    <main className="wrap">
      {/* 상단 바: 좌(뒤로가기) - 중앙(이전/타이틀/다음) - 우(오늘) */}
      <div className="bar">
        <div className="left">
          <Link href="/dashboard" className="btn dark">← 뒤로가기</Link>
        </div>

        <div className="center">
          <button className="nav" onClick={()=>move(-1)}>◀</button>
          <div className="title">{y} 년 {String(m+1).padStart(2,"0")} 월</div>
          <button className="nav" onClick={()=>move(1)}>▶</button>
        </div>

        <div className="right">
          <button className="btn dark" onClick={today}>오늘</button>
        </div>
      </div>

      {/* 요일 */}
      <div className="head">
        {WEEKS.map((w,i)=>(<div key={w} className={"hcell"+(i===0?" sun":"")}>{w}</div>))}
      </div>

      {/* 달력 */}
      <div className="grid">
        {days.map((d,i)=>{
          const isSun = d.dow===0;
          const cls = ["cell"]; if(d.other) cls.push("other"); if(isSun || d.holiday) cls.push("holiday");
          return (
            <div key={i} className={cls.join(" ")}>
              <div className="chead">
                <span className="num">{d.date.getDate()}</span>
                <button className="add" onClick={()=>addEvent(d.key)}>+ 등록</button>
              </div>
              {d.holiday && <div className="hname">{d.holiday}</div>}
              <div className="items">
                {d.events.slice(0,10).map((ev,idx)=>(
                  <div key={idx} className="item">
                    {(ev.time?`${ev.time} `:"") + ev.title + (ev.type?` / ${ev.type}`:"")}
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      <style jsx>{`
        .wrap{ min-height:100svh; background:linear-gradient(180deg,#fff,#f6f7f8); color:#111; padding:12px; }

        .bar{
          display:grid; grid-template-columns:1fr auto 1fr;
          align-items:center; gap:12px; width:100%; margin-bottom:10px;
        }
        .left{ justify-self:start; }
        .right{ justify-self:end; }

        /* 중앙: 이전 / 타이틀 / 다음 */
        .center{ display:flex; align-items:center; gap:8px; justify-content:center; }
        .title{
          height:36px; display:inline-flex; align-items:center; justify-content:center;
          padding:0 14px; border-radius:10px; border:1px solid #e5e7eb; background:#fff;
          font-weight:900; font-size:18px; letter-spacing:.3px;
        }

        .btn, .nav{ height:36px; display:inline-flex; align-items:center; }
        .btn{ padding:0 12px; border-radius:10px; font-weight:800; cursor:pointer; }
        .btn.dark{ border:1px solid #111; background:#111; color:#fff; }
        .btn.dark:hover{ filter:brightness(1.06); }

        .nav{ padding:0 10px; border-radius:10px; cursor:pointer; border:1px solid #e5e7eb; background:#fff; }

        .head{ display:grid; grid-template-columns:repeat(7,minmax(0,1fr)); gap:10px; width:100%; }
        .hcell{ padding:6px 8px; border-radius:10px; background:#fff; border:1px solid #e5e7eb; text-align:center; font-weight:800; color:#333; }
        .hcell.sun{ color:#e11d48; }

        .grid{ display:grid; grid-template-columns:repeat(7,minmax(0,1fr)); gap:10px; width:100%; }
        .cell{ min-height:160px; background:#fff; border:1px solid #e5e7eb; border-radius:12px; padding:10px; display:flex; flex-direction:column; gap:6px; box-shadow:0 4px 10px rgba(0,0,0,.03); }
        .cell.other{ background:#fbfbfb; color:#9aa0a6; }
        .cell.holiday .num{ color:#e11d48; }

        .chead{ display:flex; align-items:center; justify-content:space-between; }
        .num{ font-weight:700; }
        .add{ border:1px solid #d1d5db; background:#fff; border-radius:8px; padding:2px 8px; font-size:12px; cursor:pointer; }
        .add:hover{ background:#f3f4f6; }
        .hname{ font-size:12px; color:#e11d48; }
        .items{ display:flex; flex-direction:column; gap:4px; }
        .item{ font-size:12.5px; color:#111; background:#f6f7f8; border:1px solid #e5e7eb; border-radius:8px; padding:4px 6px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
        @media (min-height:900px){ .cell{ min-height:180px; } }
      `}</style>
    </main>
  );
}